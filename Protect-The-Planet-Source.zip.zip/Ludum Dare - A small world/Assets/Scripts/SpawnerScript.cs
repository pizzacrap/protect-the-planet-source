﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpawnerScript : MonoBehaviour {
	
	public float secondsUntilSpawn = 5f;
	public float timeDecrease = 1f;
	public float timeUntilDecrease = 5f;
	public float maxSecondsUntilSpawn = 0.5f;

	public GameObject badGuy;

	void Start () {
		Invoke ("Spawn", secondsUntilSpawn);
		Invoke ("SpawnTimeDecrease", timeUntilDecrease);
	}

	void Spawn () {
		int lrud = Random.Range (0, 2);
		float randomY = Random.Range (-6, 6);
		float dir = 0;
		if (lrud == 1) { dir = 10; }
		if (lrud == 0) { dir = -10; }
		Instantiate (badGuy, new Vector2 (dir, randomY), Quaternion.identity);
		Invoke ("Spawn", secondsUntilSpawn);
	}

	void SpawnTimeDecrease () {
		if (secondsUntilSpawn > maxSecondsUntilSpawn) {
			secondsUntilSpawn += -timeDecrease;
		} else {
			if (timeUntilDecrease < 8f) {
				timeUntilDecrease *= 2;
			} else {
				secondsUntilSpawn += -(timeDecrease / 4);
			}
		}
		Invoke ("SpawnTimeDecrease", timeUntilDecrease);
	}
}