﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;

public class CollectingPoint : MonoBehaviour {

	// Scoring
	private int fakeScore = 0;
	private int score = 0;
	public Text scoreText;
	AudioSource aud;

	void Start () {
		aud = GetComponent <AudioSource> ();
		SetScore ();
	}

	void Update () {
		if (score < fakeScore) {
			aud.Play ();
			score += 1;
			SetScore ();
		}
	}

	void OnTriggerEnter2D (Collider2D other) {
		if (other.tag == "Point") {
			ScorePoint ();
			Destroy (other.gameObject);
		}
	}

	// Scoring
	void ScorePoint () {
		fakeScore += 1;
		SetScore ();
	}

	void SetScore () {
		scoreText.text = score.ToString ();
	}
}