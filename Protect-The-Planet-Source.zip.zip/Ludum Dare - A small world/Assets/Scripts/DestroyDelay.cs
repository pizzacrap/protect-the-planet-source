﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DestroyDelay : MonoBehaviour {
	
	public int secondsUntilDestroy = 5;

	void Start () {
		GameObject.Destroy (gameObject, secondsUntilDestroy);
	}
}