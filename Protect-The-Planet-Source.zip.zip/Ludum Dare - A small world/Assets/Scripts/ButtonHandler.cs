﻿using UnityEngine;
using System.Collections;
using UnityEngine.SceneManagement;

public class ButtonHandler : MonoBehaviour {
	public void LoadScene() { 
		SceneManager.LoadScene ("_MainScene");
	}
}