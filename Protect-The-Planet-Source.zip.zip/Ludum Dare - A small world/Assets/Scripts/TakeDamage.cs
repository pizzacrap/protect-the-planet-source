﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TakeDamage : MonoBehaviour {

	// Public Variablesfjaefnjsf
	public float health = 5; // Health equals 5 by default

	// Weird Stuff
	SpriteRenderer spr;
	Color cel = new Color (1, 1, 1, 1);
	float size = 1;
	public GameObject point;

	void Start () {
		spr = GetComponent <SpriteRenderer> ();
	}

	void Update () {
		// Weird Stuff
		spr.color = cel;
		transform.localScale = new Vector3 (size, size, size);
		size = Mathf.Lerp (size, 1f, 0.2f);
		if (cel.r < 1) {
			cel.r += 0.1f;
			cel.g += 0.1f;
			cel.b += 0.1f;
		}
		// Destroy if the health is below 0
		if (health <= 0) {
			int i = 0;
			for (i = Random.Range (0, 5); i < 10; i++) {
				Vector3 ay = new Vector3 (Random.Range (-1f, 1f), Random.Range (-1f, 1f), 0);
				Instantiate (point, transform.position + ay, Quaternion.identity);
			}
			GameObject.Destroy (gameObject);
		}
	}

	void OnTriggerEnter2D (Collider2D other) {
		if (other.tag == "Bullet") {
			Destroy (other.gameObject);
			health += -1;
			cel = new Color (0, 0, 0, 1);
			size = 1.3f;
		}
	}
}