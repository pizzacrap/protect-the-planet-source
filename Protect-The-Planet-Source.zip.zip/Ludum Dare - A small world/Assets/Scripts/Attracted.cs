﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Attracted : MonoBehaviour {
	
	public GameObject attractedTo;
	public float strengthOfAttraction = 5.0f;
	Rigidbody2D rig;

	void Start () {
		attractedTo = GameObject.FindGameObjectWithTag ("Player");
		rig = GetComponent <Rigidbody2D> ();
	}

	void FixedUpdate ()
	{
		Vector3 direction = attractedTo.transform.position - transform.position;
		rig.AddForce (strengthOfAttraction * direction);

	}
}
