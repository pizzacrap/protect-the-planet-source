﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class KeepAlive : MonoBehaviour {

	AudioSource aud;
	GameObject[] musicObject;

	void Start () {
		aud = GetComponent <AudioSource> ();
		musicObject = GameObject.FindGameObjectsWithTag ("GameMusic");
		if (musicObject.Length == 1 ) {
			aud.Play ();
		} else {
			for(int i = 1; i < musicObject.Length; i++){
				Destroy(musicObject[i]);
			}
		}
	}

	void Awake () {
		DontDestroyOnLoad (this.gameObject);
	}
}