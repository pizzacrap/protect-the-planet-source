﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class DieOnHit : MonoBehaviour {

	public Text youLose;

	void Start () {
		Color c = youLose.color;
		c.a = 0;
		youLose.color = c;
	}

	void Update () {
		if (Input.GetKey (KeyCode.R)) {
			SceneManager.LoadScene ("_MainScene");
			Time.timeScale = 1;
		}
	}

	void OnTriggerEnter2D (Collider2D other) {
		if (other.gameObject.CompareTag ("Respawn")) {
			Time.timeScale = 0;
			Color c = youLose.color;
			c.a = 1;
			youLose.color = c;
		}
	}
}