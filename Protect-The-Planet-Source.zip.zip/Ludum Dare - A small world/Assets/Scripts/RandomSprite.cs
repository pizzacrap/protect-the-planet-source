﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RandomSprite : MonoBehaviour {
	
	SpriteRenderer sr;
	public Sprite sprite0;
	public Sprite sprite1;

	void Start () {
		sr = GetComponent <SpriteRenderer> ();
		if (Random.Range (0, 2) == 0) { sr.sprite = sprite0; }
		else { sr.sprite = sprite1; }
	}
}