﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BadGuyScript : MonoBehaviour {

	public float speed = 3f;

	GameObject player;
	Transform target;

	void Start () {
		speed += Random.Range (-2.5f, 2f);
		player = GameObject.FindGameObjectWithTag ("Player");
		target = player.transform;
		if (player.transform.position.x < transform.position.x) {
			SpriteRenderer spr = GetComponent <SpriteRenderer> ();
			spr.flipX = true;
		}
	}

	void Update () {
		float step = speed * Time.deltaTime;
		transform.position = Vector3.MoveTowards (transform.position, target.position, step);
	}
}