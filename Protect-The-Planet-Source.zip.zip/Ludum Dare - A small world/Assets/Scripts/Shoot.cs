﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Shoot : MonoBehaviour {
	
	public GameObject sr;
	float size = 0.6f;

	public float msBetweenShots = 100;
	float shootSpeed = 8;
	float nextShotTime;
	public Transform bullet;

	void setShootSpeed(float sp) {
		shootSpeed = sp;
	}

	void Update () {
		sr.transform.localScale = new Vector3 (size, size, size);
		size = Mathf.Lerp (size, 0.6f, 0.2f);
		// Look to mouse
		Vector3 mouseScreen = Input.mousePosition;
		Vector3 mouse = Camera.main.ScreenToWorldPoint(mouseScreen);
		transform.rotation = Quaternion.Euler(0, 0, Mathf.Atan2(mouse.y - transform.position.y, mouse.x - transform.position.x) * Mathf.Rad2Deg - 90);
		if (Input.GetMouseButton (0)) {
			if (Time.time > nextShotTime) {
				size = 0.62f;
				nextShotTime = Time.time + msBetweenShots / 1000;
				Instantiate (bullet, transform.position, transform.rotation * Quaternion.Euler(0, 0, 90));
			}
		}
	}
}